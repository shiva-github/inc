<?php

echo 'comments';
comment_form();