



<?php if ( is_active_sidebar( 'fire_sidebar' ) ) : ?>
	<div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">
		<?php dynamic_sidebar( 'fire_sidebar' ); ?>
	</div><!-- #primary-sidebar -->
<?php endif; ?>