<?php

 wp_link_pages();